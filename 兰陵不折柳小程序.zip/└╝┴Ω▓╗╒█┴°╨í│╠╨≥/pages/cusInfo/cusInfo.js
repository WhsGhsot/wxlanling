// pages/cusInfo/cusInfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   //flag=gis为现货 ad为预购
    var flag=options.flag;
    this.setData({
      flag:flag
    })
    //两者都为true才可跳转页面
    var  flag_cusInfo=false,flag_taxInfo=false;
    var cusInfo = '';
    var taxInfo = "";
    /*调用微信API 返回用户选择的地址信息*/
    wx.chooseAddress({
      success: function (res) {
        cusInfo = [{
          'userName': res.userName, 'provinceName': res.provinceName, 'cityName': res.cityName,
          'countyName': res.countyName, 'detailInfo': res.detailInfo, 'telNumber': res.telNumber
        }]
        //缓存用户选择的地址信息
        wx.setStorage({
          key: 'cusInfo',
          data: cusInfo,
        });
        /*纳税识别信息*/
        wx.chooseInvoiceTitle({
          success: function (res) {
            //console.log(res);
            taxInfo = [{
              'title': res.title, 'companyAddress': res.companyAddress,
              'taxNumber': res.taxNumber, 'bankName': res.bankName
            }]
            //缓存纳税识别信息
            wx.setStorage({
              key: 'taxInfo',
              data: taxInfo,
            });
            
            //console.log(taxInfo);
            wx.redirectTo({
              url: '../pay/pay?flag='+flag,
            })
          },
          fail: function (res) {
          //得到缓存对象,看看是否有对象,若有,则不提示信息,否则提示信息
          wx.getStorage({
            key: 'taxInfo',
            success: function(res) {},
            fail:function(res){
              wx.showModal({
                title: '温馨提示',
                content: '必须对发票信息进行许可才能提交订单',
                showCancel: false
              })
            }
          })
              
          }
        });
      },
      fail:function(res)
      {
        wx.getStorage({
          key: 'cusInfo',
          success: function(res) {},
          fail:function(res)
          {
            wx.showModal({
              title: '温馨提示',
              content: '必须对收货地址进行许可才能提交订单',
              showCancel: false
            })
          }
        })
        
      }
    });
  },
 /*点击获取权限触发按钮 */
 cusInfo:function()
 {
   var flag=this.data.false;
   wx.getSetting({
     success:function(res)
     {
       if (!res.authSetting['scope.address'] || !res.authSetting['scope.invoiceTitle'])
       {
         wx.openSetting({
           success:function(res)
           {
             if(res.authSetting['scope.address']||res.authSetting['scope.invoiceTitle'])
             {
               wx.redirectTo({
                 url: '../cusInfo/cusInfo?flag='+flag,
               })
             }
           }
         });
       }
       else
       {
         wx.showModal({
           title: '温馨提示',
           content: '信息已授权',
           showCancel:false
         })
       }
     }
   });

   
 },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})