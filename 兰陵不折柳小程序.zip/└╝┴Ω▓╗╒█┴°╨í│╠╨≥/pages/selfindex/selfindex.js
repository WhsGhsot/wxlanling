// pages/selfindex/selfindex.js
//var     images=['../imgs/yilu_1.jpg','../imgs/yilu_2.jpg','../imgs/yilu_4.jpg']
Page({

  /**
   * 页面的初始数据
   */
  data: {


    images:'',
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    /*上方广告图片attribute  image width  height*/
    imgArr:[],
    /*中间内容区*/
    //主营软件
    softs: [{ 'name': 'U8 13.0', 'id': 'u8', 'img': '../imgs/U8.jpg' }, { 'name': 'T系列', 'id': 't', 'img': '../imgs/T.jpg' }, { 'name': '好会计', 'id': 'hkj', 'img': '../imgs/HKJ.jpg' }],
    //其他业务
    other: [{ 'name': '软件升级', 'id': 'sj', 'img': '../imgs/SJ.jpg' }, { 'name': 'U8远程接入', 'id': 'remote', 'img': '../imgs/Remote.jpg' }, { 'name': 'T系列跨年度', 'id': 'tSpan', 'img': '../imgs/TSpan.jpg' }],
    //理财/模块
    manager: [{ 'name': '友金所', 'id': 'yjs', 'img': '../imgs/YJS.jpg' }, { 'name': 'U8模块查询', 'id': 'u8modal', 'img': '../imgs/U8Modal.jpg' }, { 'name': 'T模块查询', 'id': 'cjmodal', 'img': '../imgs/TModal.jpg' }],
    /*下方区域联系人*/
    connecter:{'name':'江流儿','mobile':'18189708861'},
    //促销信息
    offInfo:'商城内现货商品满1000立减全额10%，商品预定减免总额13%,4公里内免费送货上门,货到付款',
  },

  /*点击下方的内容区(软件 升级....)时触发的函数  param:id 划分的id */
clickDive:function(e)
{
  var  id=e.currentTarget.dataset.id;
  var url='';
  switch(id)
  {
    case 'u8':url='../u8/u8';break;
    case 't':url='../tseries/tseries';break;
    case 'hkj':url='../hkj/hkj';break;
    case 'sj':url='../sj/sj';break;
    case 'remote':url='../remote/remote';break;
    case 'tSpan':url='../tspan/tspan';break;
    case 'yjs':url='../yjs/yjs';break;
    case 'u8modal':url='../u8modal/u8modal';break;
    case 'cjmodal':url='../cjmodal/cjmodal';break;
  }
  wx.navigateTo({
    url: url,
  })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    /*加载广告位信息*/
    wx.request({
      url: 'https://ghostwhs.cn/cgi-bin/server.py',
      data: {
        flag: 'advertisement'
      },
      success: function (res) {
        var images = res.data;
        that.setData({
          images: images
        });

        var imgArr = that.data.imgArr;
        var images = that.data.images;
        var windowWidth = '';
        wx.getSystemInfo({
          success: function (res) {
            windowWidth = res.windowWidth;
          },
        });
        images.forEach(function (item, index, arr) {
          imgArr[index] = { 'image': item, 'width': windowWidth }
        });
        that.setData({
          imgArr: imgArr
        });
      }
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    

   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})