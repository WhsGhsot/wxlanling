// pages/yjs/yjs.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yjs: {
      'syn': '友金所由用友网络(股票代码：600588)、深圳力合金控与银行专家管理团队联合设立。友金所致力于提供专业的全流程金融信息服务，打造安全、便捷、丰富的互联网投融资信息服务平台。友金所背倚用友集团、力合金控的品牌资源、客户渠道、技术支持、管理经验等，依托专业银行专家管理团队，打造了：网贷平台——友金服 、综合型平台——友金社(www.yyexch.com) ，为客户及机构提供安全、稳健的互联网投融资信息服务。', 'manage': '友金-e富是友金所首款个人借贷服务。友金所作为需要融资的借款方与拥有闲置资金的投资方之间的平台，帮助借贷双方方便快捷地完成投资借贷，并委托用友集团旗下的担保公司对借款方的信用进行审查与核实，提供担保。YY理财是友金所推出的“投资人在锁定期内对借款项目进行优先自动投资及到期退出或提前退出时优先自动转让债权”的服务计划，是自动投标工具。', 'images': [{ 'image': 'https://ghostwhs.cn/icons/imgs/yjs_1.jpg' }, { 'image': 'https://ghostwhs.cn/icons/imgs/yjs_2.jpg' }, { 'image': 'https://ghostwhs.cn/icons/imgs/yjs_3.jpg' }, { 'image': 'https://ghostwhs.cn/icons/imgs/yjs_4.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/yjs_5.png' }]}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})