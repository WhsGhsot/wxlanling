// pages/pay/pay.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    //备注
    remark:'可选择填写备注',
    //收货人信
    cusInfo: [{ 'userName': '' }],
    //派送员信息
    connect: { 'name': '江流儿', 'mobile': '18189708861' },
    //滚动窗口对象
    scrol: '',
    //购物车对象
    car: '',
    //总金额
    moneyAll: 0,
    //优惠额
    cashOff: 0,
    //上方选择地址对象
    selAdd: '',
    //下方提交订单对象
    sendOrder: '',
    //优惠百分比
    // offPercent: 0.1,
    //优惠百分比gis为现货 ad为预购
    offPercent:{'gis':0.1,'ad':0.13},
    total:0,
    godsHeight:100,
    //纳税识别信息
    taxInfo: {'title':''},
    //flag=gis 表示现货  flag=ad表示预购
    flag:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //flag=gis为现货   ad为预购
    var flag=options.flag;
    var that = this;
    that.setData({
      flag:flag
    })
    var moneyAll;
    //console.log(flag);
    if(flag=='gis')
    {
      //购物车相关缓存
      wx.getStorage({
        key: 'car',
        success: function (res) {
          that.setData({
            car: res.data
          })
        },
      });
      moneyAll= wx.getStorageSync("moneyAll");
    }
    //商品预购
    else if(flag=='ad')
    {
      //购物车相关缓存
      wx.getStorage({
        key: 'car_ad',
        success: function (res) {
          that.setData({
            car: res.data
          })
        },
      });
      moneyAll = wx.getStorageSync("moneyAll_ad");
    }
    //得到缓存收货信息
    wx.getStorage({
      key: 'cusInfo',
      success: function (res) {
        that.setData({
          cusInfo: (res.data)
        })
      },
    });

    //得到缓存开票信息
    wx.getStorage({
      key: 'taxInfo',
      success: function (res) {
        that.setData({
          taxInfo: res.data[0]
        })
      },
    });
    //console.log("联系人信息："+that.data.cusInfo);
    var windowHeight='';
    var windowWidth='';
    wx.getSystemInfo({
      success: function (res) {
        windowHeight=res.windowWidth;
        windowWidth=res.windowWidth;
        that.setData({
          selAdd: { 'width': res.windowWidth, 'height': 100 },
          sendOrder: { 'width': res.windowWidth, 'height': 50 },
        })
      },
    });
   // console.log(windowHeight + "," + that.data.selAdd.height + "," + that.data.sendOrder.height);
    that.setData({
      scrol: { 'width': windowWidth, 'height': windowHeight-100 }
    });
    //console.log(that.data.scrol.width+","+that.data.scrol.height);
    this.setData({
      moneyAll:moneyAll
    })
    that.setData({
      cashOff:  parseInt(that.data.moneyAll * that.data.offPercent[flag])
    });
    that.setData({
      total:parseInt(that.data.moneyAll-that.data.cashOff)
    })
    //console.log("moneyAll:"+that.data.moneyAll+";cashOff:"+that.data.cashOff);
  },
  /*选择收货地址 gis为现货  ad为预定*/
  selAdd: function (e) {
    var that=this;

    /*wx.navigateTo({
      url: '../cusInfo/cusInfo?flag='+that.data.flag,
    })*/
    wx.redirectTo({
      url: '../cusInfo/cusInfo?flag=' + that.data.flag,
    })
  },

  remark:function(e)
  {
     this.setData({
       remark:e.detail.value
     })
  },

  /*点击提交订单时触发的方法*/
  sendOrder: function (e) {
    //console.log(e);
    var that = this;
    //发送订单信息至自己的邮箱中
    //console.log(that.data.cashOff,that.data.moneyAll,that.data.total);
     var car = JSON.stringify(that.data.car);
     var cusInfo=that.data.cusInfo;
     var taxInfo=that.data.taxInfo;
     if(cusInfo[0].userName=='')
     {
       wx.showModal({
         title: '温馨提示',
         content: '客官,未输入收货地址,请核对上方地址',
         showCancel:false
       });
       return;
     }

     if(taxInfo.title=='')
     {
        wx.showModal({
          title: '温馨提示',
          content: '客官,请填写上方发票信息',
          showCancel:false
 
        })
     }
     //console.log(taxInfo);
    cusInfo=JSON.stringify(cusInfo);
    taxInfo=JSON.stringify(taxInfo);
    //console.log(that.data.car);
     //console.log(car);
     //如果没有收货地址,则不可提交订单
    wx.request({
      url: 'https://ghostwhs.cn/cgi-bin/server.py',
      header:{
         "Content-Type":"application/json"
      },
      data: {
        car: car,
        moneyAll:that.data.moneyAll,
        cashOff:that.data.cashOff,
        total:that.data.total,
        cusInfo:cusInfo,
        taxInfo:taxInfo,
        flag:'order',
        style:that.data.flag,
        remark:that.data.remark
      },
      success: function (res) {
        var  key=that.data.flag=='gis'?'car':'car_ad';
        //清空购物车缓存
        wx.removeStorage({
          key: key,
          success: function(res) {

           //导航至受理页面
            wx.reLaunch({
              url: '../payresult/payresult?flag=' + that.data.flag,
            });
           /* wx.showModal({
              title: '温馨提示',
              content: '您的订单已受理,稍后会由工作人员向您确认收货信息',
              showCancel:false,
              success:function(){
                //导航至首页
                wx.redirectTo({
                  url: '../selfindex/selfindex'
                })
              }
            });*/
          },
        });
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    /*wx.navigateBack({
      delta:2
    })*/
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})