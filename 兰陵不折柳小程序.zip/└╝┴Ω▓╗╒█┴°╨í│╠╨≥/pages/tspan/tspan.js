// pages/tspan/tspan.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    zzt: [{ 'image': 'https://ghostwhs.cn/icons/imgs/zzt_1.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_2.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_3.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_4.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_5.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_6.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_7.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_8.png' }, { 'image': 'https://ghostwhs.cn/icons/imgs/zzt_9.png' }]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})