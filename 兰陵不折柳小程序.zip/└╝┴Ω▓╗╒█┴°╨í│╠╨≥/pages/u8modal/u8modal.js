// pages/u8modal/u8modal.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

    modals: {'cw':[{ 'index': 'gl', 'name': '总账','img':'../imgs/gl.jpg'}, { 'index': 'ar', 'name': '应收款管理' ,'img':'../imgs/ar.jpg'}, { 'index': 'ap', 'name': '应付款管理','img':'../imgs/ap.jpg' }, { 'index': 'fa', 'name': '固定资产','img':'../imgs/fa.jpg' }, { 'index': 'fab', 'name': '资产条码','img':'../imgs/fab.jpg' }, { 'index': 'ufo', 'name': 'UFO报表','img':'../imgs/ufo.jpg' }, { 'index': 'im', 'name': '发票管理','img':'../imgs/im.jpg' }, { 'index': 'cm', 'name': '出纳管理','img':'../imgs/cm.jpg' }, { 'index': 'eb', 'name': '费用管理','img':'../imgs/eb.jpg' }, { 'index': 'wr', 'name': '网上报销','img':'../imgs/wr.jpg' }, { 'index': 'wb', 'name': '网上银行','img':'../imgs/wb.jpg' }],'gyl':[{ 'index': 'cam', 'name': '合同管理','img':'../imgs/cam.jpg' }, { 'index': 'pm', 'name': '采购管理','img':'../imgs/pm.jpg' }, { 'index': 'inm', 'name': '库存管理','img':'../imgs/inm.jpg' }, { 'index': 'ia', 'name': '存货核算','img':'../imgs/ia.jpg' }, { 'index': 'sm', 'name': '销售管理','img':'../imgs/sm.jpg' }],'hr':[{ 'index': 'pem', 'name': '人事管理','img':'../imgs/pem.jpg' }, { 'index': 'pam', 'name': '薪资管理','img':'../imgs/pam.jpg' }, { 'index': 'pc', 'name': '人事合同','img':'../imgs/pc.jpg' }]
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /*点击模块名称 跳转页面  param:index(模块索引)*/
  selModal:function(e)
  {
      var index=e.currentTarget.dataset.index;
      wx.navigateTo({
        url: '../modal/modal?index='+index,
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})