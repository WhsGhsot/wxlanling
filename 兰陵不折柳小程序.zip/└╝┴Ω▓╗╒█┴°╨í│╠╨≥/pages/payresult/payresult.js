// pages/payresult/payresult.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      courier:{'name':'江流儿','telNum':'18189708861'},
      //提示信息,根据flag的不同而不同
      reminder:'',
      time:6,
      //时间到后的编号
      timeoutNumber:'',
      //定时的编号
      intervalNumber:''
  },
 //点击主页触发
 backIndex:function()
 {
   var that=this;
   //清除定时任务
   clearInterval(that.data.intervalNumber);
   clearTimeout(that.data.timeoutNumber);
    wx.reLaunch({
      url: '../selfindex/selfindex',
   })
 },
 //定时器  改变跳转主页的事件
 chageTime:function()
 {
  var that=this;
  var time=that.data.time-1;
  that.setData({
     time:time
  })  
 },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    //定时任务
   var intervalNum= setInterval(that.chageTime,1000);
   var timeoutNum=setTimeout(that.backIndex,that.data.time*1000);
   this.setData({
     intervalNumber:intervalNum,
     timeoutNumber: timeoutNum
   });

   var flag=options.flag;
   //var flag='ad';
   //现货
   if(flag=='gis')
   {
     that.setData({
       reminder:'正在核对订单,请您耐心等待....'
     })
   }
   //预购
   else if(flag=='ad')
   {
    that.setData({
      reminder:'预购商品预期5日内即可收货,请您耐心等待....'
    })
   }
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})