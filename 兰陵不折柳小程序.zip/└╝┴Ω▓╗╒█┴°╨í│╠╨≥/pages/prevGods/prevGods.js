// pages/godsIndex/godsIndex.js
/*左侧产品分类*/
var categories = [
  { 'name': '套打凭证', 'id': 'td' },
  { 'name': '空白凭证', 'id': 'kb' },
  { 'name': '财务单据', 'id': 'cw' },
  { 'name': '配套装订', 'id': 'pt' },
  { 'name': '装订机', 'id': 'zd' },
  { 'name': '办公用品', 'id': 'bg' }
]
/*各分类商品总数*/
//var godsNUm = [17, 2, 2, 1, 2, 1]
var godsNum=[]

//最低额度
var moneyLimit = '1000'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categories: categories,
    //gods:gods,
    gods: [],
    //商品图片 各三个  key:商品id  value:imgs
    godsImgs: { 'KPJ101-A4': [{ 'image': '' }] },
    //左侧导航条对象  属性:width height
    left: { 'width': '100', 'height': '' },
    //右侧滚动窗口对象 属性:width height  toView
    right: { 'width': '', 'height': '' },
    //右侧对应左侧Id
    curId: 'td',
    //右侧视图
    toView: 'KPJ101-A4',
    //右侧商品高度
    godsHeight: '100',
    //购物车
    car: [],
    //购物车属性
    carAttributes: {},
    //提示信息
    alert: '差' + moneyLimit + '可送',
    //总金额
    moneyAll: 0,
    //购物车展开
    carExpan: {},
    //最低需要购买的金额
    moneyLimit: moneyLimit,
    offCash: 0.1,
    //商品细节对象  属性  display image  name  info  special
    godsDetail: { 'display': 'none', 'imgs': [], 'name': 'aa', 'info': 'aa', 'special': 'a' },
    //各滑动高度
    top_1: '',
    top_2: '',
    top_3: '',
    top_4: '',
    top_5: '',
    top_6: ''

  },
  /*点击商品时调用商品明细*/
  godsDetail: function (e) {
    var godsDetail = this.data.godsDetail;
    var gods = this.data.gods;
    var id = e.currentTarget.dataset.id;
    console.log(id);
    gods['td'].forEach(function(item,index,arr){
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });
    gods['kb'].forEach(function (item, index, arr) {
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });
    gods['cw'].forEach(function (item, index, arr) {
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });
    gods['pt'].forEach(function (item, index, arr) {
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });
    gods['zd'].forEach(function (item, index, arr) {
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });
    gods['bg'].forEach(function (item, index, arr) {
      if (item.id == id) {
        godsDetail.imgs = item.imgs;
        godsDetail.name = item.name;
        godsDetail.info = item.info;
        godsDetail.special = item.special;
      }
    });

    godsDetail.display = godsDetail.display == 'none' ? 'display' : 'none';
    this.setData({
      godsDetail: godsDetail
    })
  },

  /*点击购物车中的增加时增加商品数量*/
  addNum: function (e) {
    var id = e.target.dataset.id;
    var count = e.target.dataset.count;
    //购物车总价
    var moneyAll = this.data.moneyAll;
    var car = this.data.car;
    car.forEach(function (item, i, arr) {
      if (item.id == id) {
        //若添加的商品总数小于库存，则数量+1
        if (item.num < parseInt(count)) {

          item.num = parseInt(item.num) + 1;
          moneyAll += item.price;
        }
        return;
      }
    });
    //修改购物车
    this.setData({
      car: car
    });
    //console.log(car);
    //更改总价
    this.setData({
      moneyAll: moneyAll
    });
    //console.log(this.data.car);
    var moneyBal = 0;
    if (moneyAll < this.data.moneyLimit) {
      moneyBal = this.data.moneyLimit - moneyAll;
    };
    //若差额大于0  则修改提示信息
    if (moneyBal > 0) {
      this.setData({
        alert: '差' + moneyBal.toString() + '起送'
      })
    }
    //缓存购物车对象
    this.storageCar(car);

  },

  /*减少商品触发函数*/
  redNum: function (e) {
    //得到商品id
    var id = e.target.dataset.id;
    //总价
    var moneyAll = this.data.moneyAll;
    var car = this.data.car;
    car.forEach(function (item, i, arr) {
      if (item.id == id) {
        item.num = parseInt(item.num) - 1;
        moneyAll -= item.price;
        //如果商品数目为0则删除商品
        if (item.num <= 0) {
          car.splice(i, 1);
        }
        return;
      }
    })
    //修改购物车
    this.setData({
      car: car
    })
    //修改总价
    this.setData({
      moneyAll: moneyAll
    })
    //console.log(this.data.car);
    var moneyBal = 0;
    if (moneyAll < this.data.moneyLimit) {
      moneyBal = this.data.moneyLimit - moneyAll;
    }
    //若差额大于0  则修改提示信息
    if (moneyBal > 0) {
      this.setData({
        alert: '差' + moneyBal.toString() + '起送'
      })
    }
    //缓存购物车对象
    this.storageCar(car);
  },
  /*点击清空购物车触发函数*/
  clearCar: function (e) {
    this.setData({
      car: [],
      moneyAll: 0,
      alert: '差' + this.data.moneyLimit + '起送'
    });
    //清除缓存
    wx.clearStorage();
  },
  /*右侧滚动触发函数*/
  scroll: function (e) {

    //取得滚动所划过的高度
    var scrollTop = e.detail.scrollTop;
    //console.log(scrollTop);
    //各滑动区域范围
    var id = '';
    //对高度进行判断
    if (scrollTop >= 0 & scrollTop < this.data.top_1) {
      id = 'td'
    }
    else if (scrollTop >= this.data.top_1 & scrollTop < this.data.top_2) {
      id = 'kb'
    }
    else if (scrollTop >= this.data.top_2 & scrollTop < this.data.top_3) {
      id = 'cw'
    }
    else if (scrollTop >= this.data.op_3 & scrollTop < this.data.top_4) {
      id = 'pt'
    }
    else if (scrollTop >= this.data.top_4 & scrollTop < this.data.top_5) {
      id = 'zd'
    }
    else if (scrollTop >= this.data.top_5 & scrollTop < this.data.top_6) {
      id = 'bg'
    }
    //更改curId
    this.setData({
      curId: id
    })
    //console.log(this.data.curId);
  },
  /*点击左侧tab 右侧scrol移动*/
  scrolMove: function (e) {
    var id = e.target.dataset.id;
    //console.log(id);
    var toView = '';
    switch (id) {
      case 'td': toView = 'KPJ101-A4'; break;
      case 'kb': toView = 'SJ500110'; break;
      case 'cw': toView = 'L030107'; break;
      case 'pt': toView = 'SZ600135'; break;
      case 'zd': toView = 'F5082'; break;
      case 'bg': toView = 'FM124'; break;
        break;
    }
    this.setData({
      curId: id
    })
    this.setData({
      toView: toView
    })
  },
  /*点击'去结算时触发的函数'*/
  payNow: function (e) {
    //判断购物车里是否有商品 --如果没有则返回
    if (this.data.car.length == 0)
      return;
    //判断总价是否到限额,未到则返回
    var moneyAll = this.data.moneyAll;
    if (moneyAll < this.data.moneyLimit) {
      return;
    }
    //缓存moneyAll
    wx.setStorage({
      key: 'moneyAll_ad',
      data: moneyAll,
    })

    //console.log(moneyAll);
    wx.navigateTo({
      url: '../pay/pay?flag=ad'
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    var carAttributes = {};
    var prevGods='';
    var left = that.data.left;
    var right = that.data.right;
    var windowWidth = '';
    //var godsDetail = that.data.godsDetail;

    wx.getSystemInfo({
      success: function (res) {
        windowWidth = res.windowWidth;
        carAttributes = { 'width': (res.windowWidth).toString(), 'top': (res.windowHeight - 30).toString(), 'show': false, 'height': 30 };
        //left.height = res.screenHeight;
        //right.height = res.screenHeight;
        left.height = res.windowHeight - 60;
        right.height = res.windowHeight - 60;
        right.width = res.windowWidth - left.width;
        //godsDetail.width=res.windowWidth;
        //godsDetail.height=res.windowWidth;

      },
    })
    this.setData({
      left: left,
      right: right,
      carAttributes: carAttributes,
      carExpan: { 'carDisplay': 'none', 'height': 100 }
    });
    //console.log(that.data.left.height);
   
    var flag = 'prevGods';
    var that = this;
    //加载右侧商品信息
    wx.request({
      url: 'https://ghostwhs.cn/cgi-bin/server.py',
      data:
        {
          flag: flag
        },
      success: function (res) {
        that.setData({
          gods: res.data
        });
        prevGods = that.data.gods;
        var bg=prevGods['bg'];
        var cw=prevGods['cw'];
        var pt=prevGods['pt'];
        var kb=prevGods['kb'];
        var td = prevGods['td'];
        var zd=prevGods['zd'];
      
        godsNum.push(td.length);
        godsNum.push(kb.length);
        godsNum.push(cw.length);
        godsNum.push(pt.length);
        godsNum.push(zd.length);
        godsNum.push(bg.length);


        var top_1 = godsNum[0] * that.data.godsHeight - that.data.godsHeight;
        var top_2 = godsNum[1] * that.data.godsHeight + top_1;
        var top_3 = godsNum[2] * that.data.godsHeight + top_2;
        var top_4 = godsNum[3] * that.data.godsHeight + top_3;
        var top_5 = godsNum[4] * that.data.godsHeight + top_4;
        var top_6 = godsNum[5] * that.data.godsHeight + top_5;
       

        that.setData({
          top_1: top_1,
          top_2: top_2,
          top_3: top_3,
          top_5: top_5,
          top_6: top_6,
          top_4: top_4,
        });
      }
    });

   /* that.setData({
      godsDetail: godsDetail
    });*/
  },
  /*点击差....起送时*/
  showCar: function (e) {
    var carDisplay = this.data.carExpan.carDisplay == 'none' ? 'display' : 'none';
    var show = this.data.carAttributes.show == false ? true : false;
    var carExpan = this.data.carExpan;
    carExpan.carDisplay = carDisplay;
    this.setData({
      carExpan: carExpan
    });

  },
  /*缓存购物车方法 param  car:购物车对象*/
  storageCar: function (car) {
    wx.setStorage({
      key: 'car_ad',
      data: car,
    })
  },
  /*点击添加加入购物车*/
  addCar: function (e) {

    //产品id
    var id = e.target.dataset.id;
    //产品名称
    var name = e.target.dataset.name;
    //销售单位
    var unit = e.target.dataset.unit;
    //产品价格
    var price = parseInt(e.target.dataset.price);

    //产品图片
    var image = e.target.dataset.image;
    //购物车总价
    var moneyAll = this.data.moneyAll;
    //购物车总价与最低额度之间的差额
    var moneyBal = 0;
    //console.log(id);
    //判断是否已经存在购物车中,若无 则加入到购物车 如有则购物车数量+1
    var car = this.data.car;
    //标记是否是购物车数量+1  0：表示商品未存在于购物车  1 ：表示商品存在于购物车
    var flag = 0;


    if (car.length > 0) {
      car.forEach(function (value, index, array) {
        //若存在  则+1并跳出循环
        if (value.id == id) {
          /*if(value.num<parseInt(count))
          {
            var num = parseInt(value.num) + 1;
            value.num = num.toString();
            flag = 1;
          }*/
          var num = parseInt(value.num) + 1;
          value.num = num.toString();
          flag = 1;
          return;
        }
        //否则加入购物车并商品数量为1
      })
    }
    if (flag == 0) {
      var god = { 'id': id, 'num': '1', 'name': name, 'price': price, 'image': image, 'unit': unit }
      car.push(god);
    }


    //修改总金额
    moneyAll += price;
    //console.log(moneyAll);
    if (moneyAll < this.data.moneyLimit) {
      moneyBal = this.data.moneyLimit - moneyAll;
    }
    //若差额大于0  则修改提示信息
    if (moneyBal > 0) {
      this.setData({
        alert: '差' + moneyBal.toString() + '起送'
      })
    }
    //修改购物车总金额
    this.setData({
      moneyAll: moneyAll
    })
    //修改购物车
    this.setData({
      car: car
    })
    //缓存购物车对象
    wx.setStorage({
      key: 'car_ad',
      data: car,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})